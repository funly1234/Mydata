package com.cundong.recyclerview.sample;

/**
 * Created by cundong on 2015/11/17.
 */
public class ItemModel {
    public long id;
    public String title;
}
#SupportDemos
本工程最初仅为DiffUtil的一个Demo，后发展为讲解Google Android Support包内那些常用or冷门有用的工具类的合集。



## 索引：
合集Blog地址：

http://blog.csdn.net/column/details/13763.html  



### DiffUtil:

DiffUtils是Google官方在support-v7-24.2.0新出的一个工具类，本工程为一个讲解它使用的Demo

博文传送门：

http://blog.csdn.net/zxt0601/article/details/52562770

代码地址：

https://github.com/mcxtzhang/DiffUtils/tree/master/app/src/main/java/com/mcxtzhang/diffutils/diffutil

入口:

MainActivity.java

---

### SortedList:

关键点：
**搭配RecyclerView使用，去重，有序，自动定向刷新**

博文传送门：

待补

代码地址：

https://github.com/mcxtzhang/DiffUtils/tree/master/app/src/main/java/com/mcxtzhang/diffutils/sortedlist

入口:

SortedListActivity.java


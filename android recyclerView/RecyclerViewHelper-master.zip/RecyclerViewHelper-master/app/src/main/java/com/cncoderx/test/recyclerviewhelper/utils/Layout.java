package com.cncoderx.test.recyclerviewhelper.utils;

/**
 * @author cncoderx
 */
public enum Layout {
    linear, grid, staggered
}
